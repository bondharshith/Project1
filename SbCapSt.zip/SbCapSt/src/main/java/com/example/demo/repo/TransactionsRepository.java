package com.example.demo.repo;
 
import com.example.demo.model.Transactions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
 
import java.util.List;
 
public interface TransactionsRepository extends JpaRepository<Transactions, Integer> {
   
//    List<Transactions> findByUserId(int userId);
   
 // Custom query to join Transaction and Plan tables based on plan_id and user_id
//    @Query
//    ("SELECT t FROM Transactions t JOIN FETCH t.plan p WHERE t.user.userId = :userId");
	@Query("SELECT t FROM Transactions t JOIN FETCH t.plan p WHERE t.user.userId = :userId")
	List<Transactions> findTransactionsByUserId(@Param("userId") int userId);
}