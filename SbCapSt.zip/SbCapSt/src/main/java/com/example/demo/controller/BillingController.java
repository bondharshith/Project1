package com.example.demo.controller;
 
import com.example.demo.dto.BillingDTO;
import com.example.demo.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
 
@RestController
public class BillingController {
 
    @Autowired
    private BillingService billingService;
 
    @GetMapping("/billing/getBillingDetails/{userId}")
    public ResponseEntity<BillingDTO> getBillingDetails(@PathVariable int userId) {
        BillingDTO billingDTO = billingService.getBillingDetailsByUserId(userId);
 
        if (billingDTO == null) {
            return ResponseEntity.notFound().build();
        }
 
        return ResponseEntity.ok(billingDTO);
    }
}