
package com.example.demo.services;
 
import com.example.demo.dto.BillingDTO;
import com.example.demo.model.*;
import com.example.demo.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
@Service
public class BillingService {
 
    @Autowired
    private BillingRepository billingRepository;
 
    public BillingDTO getBillingDetailsByUserId(int userId) {
        Billing billingDetails = billingRepository.findByUserId(userId);
 
        if (billingDetails == null) {
            return null;
        }
 
        double taxRate = 0.18;
        double taxAmount = billingDetails.getCharges() * taxRate;
        double totalAmount = billingDetails.getCharges() + taxAmount;
 
        BillingDTO billingDTO = new BillingDTO();
        billingDTO.setBillId(billingDetails.getBillId());
        billingDTO.setUserId(billingDetails.getUserId());
        billingDTO.setBillingCycle(billingDetails.getBillingCycle());
        billingDTO.setCharges(billingDetails.getCharges());
        billingDTO.setDueDate(billingDetails.getDueDate());
        billingDTO.setTaxAmount(taxAmount);
        billingDTO.setTotalAmount(totalAmount);
 
        return billingDTO;
    }
}