package com.example.demo.services;
 

import java.util.List;
import java.util.stream.Collectors;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.example.demo.dto.TransactionDTO;
import com.example.demo.model.Plans;
import com.example.demo.model.Transactions;
import com.example.demo.repo.TransactionsRepository;
 
import jakarta.transaction.Transactional;
 
@Service
@Transactional
public class TransactionsService {
   
    @Autowired
    private TransactionsRepository transactionsRepository;
   
//  public List<Transactions> showTransactions(){
//      return transactionsRepository.findAll();
//  }
//  
//  public Transactions getTransactionsById(int id) {
//      return transactionsRepository.findById(id).orElse(null);
//  }
//  
//  public void addTransactions(Transactions transactions) {
//      transactionsRepository.save(transactions);
//      
//  }
//  
//   public List<Transactions> getTransactionsByUserId(int userId) {
//          return transactionsRepository.findTransactionsByUserId(userId);
//   }
     
   
    public List<TransactionDTO> getTransactionHistory(int userId) {
        List<Transactions> transactions = transactionsRepository.findTransactionsByUserId(userId);
 
        return transactions.stream()
                .map(transaction -> {
                    TransactionDTO dto = new TransactionDTO();
                    dto.setTransactionId(transaction.getTransactionId());
                    dto.setTransactionStatus(transaction.getTransactionStatus());
                    dto.setPaymentMode(transaction.getPaymentMode());
                    dto.setTransactionTimestamp(transaction.getTransactionTimestamp()); // Direct mapping
                    // Set plan details
                    Plans plan = transaction.getPlan();
                    if (plan != null) {
                        dto.setPlanName(plan.getPlanName());
                        dto.setPlanType(plan.getPlanType());
                        dto.setDataInGb(plan.getDataingb());
                        dto.setSms(plan.getSms());
                        dto.setTalkTime(plan.getTalktime());
                        dto.setPlanPrice(plan.getPrice());
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }
}
 