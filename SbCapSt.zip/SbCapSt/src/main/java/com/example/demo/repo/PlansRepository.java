package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Plans;

public interface PlansRepository extends JpaRepository<Plans, Integer> {
	 List<Plans> findByPlanName(String planName);

}
