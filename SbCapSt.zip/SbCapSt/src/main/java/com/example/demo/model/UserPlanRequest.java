package com.example.demo.model;

import lombok.Data;

@Data
public class UserPlanRequest {
    private int userId;
    private int planId;
    private String planStartDate;
}