package com.example.demo.model;
 
import java.time.LocalDateTime;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Entity
@Table(name = "transactions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Transactions{
    @Id
    @Column(name="transaction_id")
    private int transactionId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnore  // You can keep this if you don't want to serialize the 'user' object
    private Users user;
    @ManyToOne
    @JoinColumn(name = "plan_id")
//    @JsonManagedReference  // Add this to properly serialize the 'plan' field
    private Plans plan;  
//    private int planId;
    @Column(name="transaction_status")
    private String transactionStatus;
    @Column(name="payment_mode")
    private String paymentMode;
    @Column(name="transaction_timestamp")
    private LocalDateTime transactionTimestamp;
}