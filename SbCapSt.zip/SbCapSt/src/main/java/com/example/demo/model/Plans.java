package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Plans {
	@Id
	@Column(name="plan_id")
	private int planId;
	@Column(name="plan_name")
	private String planName;
	@Column(name="plan_type")
	private String planType;
     @Column(name="data_in_gb")
     private String dataingb;
     @Column(name="sms")
     private String sms;
     @Column(name="talktime")
     private String talktime;
	@Column(name="price")
	private double price;
	@Column(name="validity")
	private int validity;
	
	
	
	

}
