package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.UserPlan;

public interface UserPlanRepository extends JpaRepository<UserPlan, Integer>{
	List<UserPlan> findByUserId(int userId);
	
}
