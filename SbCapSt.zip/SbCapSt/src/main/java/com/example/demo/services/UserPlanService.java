package com.example.demo.services;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Plans;
import com.example.demo.model.UserPlan;
import com.example.demo.model.Users;
import com.example.demo.repo.PlansRepository;
import com.example.demo.repo.UserPlanRepository;
import com.example.demo.repo.UsersRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserPlanService {

    @Autowired
    private UserPlanRepository userPlanRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private PlansRepository plansRepository;

    public List<UserPlan> showUserPlan() {
        return userPlanRepository.findAll();
    }

    public UserPlan searchById(int id) {
        return userPlanRepository.findById(id).orElse(null);
    }

    public List<UserPlan> searchByUserId(int userId) {
        return userPlanRepository.findByUserId(userId);
    }

    public void addUserPlan(UserPlan userPlan) {
        userPlanRepository.save(userPlan);
    }

    public void updateUserPlan(UserPlan userPlan) {
        userPlanRepository.save(userPlan);
    }

    public void deleteUserPlan(int id) {
        userPlanRepository.deleteById(id);
    }

    public void assignPlanToUser(int userId, int planId, String planStartDate) {
        Users user = usersRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Plans plan = plansRepository.findById(planId).orElseThrow(() -> new RuntimeException("Plan not found"));
        LocalDate startDate = LocalDate.parse(planStartDate);
        LocalDate endDate = startDate.plusDays(plan.getValidity());

        UserPlan userPlan = new UserPlan();
        userPlan.setUserId(userId);
        userPlan.setPlanId(planId);
        userPlan.setPlanStartDate(planStartDate);
        userPlan.setPlanEndDate(endDate.toString());
        userPlan.setRemainingDataInGb(plan.getDataingb());
        userPlan.setRemainingSms((plan.getSms()));
        userPlan.setRemainingTalkTime(plan.getTalktime());

        userPlanRepository.save(userPlan);
    }
}