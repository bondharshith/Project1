package com.example.demo.dto;
 
import lombok.Data;
 
@Data
public class BillingDTO {
    private int billId;
    private int userId;
    private String billingCycle;
    private double charges;
//    private double payments;
    private String dueDate;
    private double taxAmount; // New field for tax amount
    private double totalAmount; // New field for total amount (charges + tax)
}