package com.example.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import java.sql.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="data_usage")
public class datausage {

    @Id
    @Column(name="usage_id")
	private int usageId;
    @Column(name="user_plan_id")
	private int userPlanId;
    @Column(name="user_id")
	private int userId;
    @Column(name="data_used")
	private double dataUsed;
    @Column(name="sms_used")
	private int smsUsed;
    @Column(name="calls_used")
	private int callsUsed;
    @Column(name="recorded_date")
	private Date recordedDate;
}
