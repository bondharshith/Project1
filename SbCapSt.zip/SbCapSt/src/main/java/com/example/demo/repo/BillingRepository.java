
package com.example.demo.repo;
 
import com.example.demo.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
 
public interface BillingRepository extends JpaRepository<Billing, Integer> {
    Billing findByUserId(int userId);
}