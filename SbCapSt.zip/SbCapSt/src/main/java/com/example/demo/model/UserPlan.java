package com.example.demo.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "user_plan")
public class UserPlan {
	
	@Id
	@Column(name="user_plan_id")
	private int userPlanId;
	@Column(name="user_id")
	private int userId;
	@Column(name="plan_id")
	private int planId;
	@Column(name="plan_start_date")
	private String planStartDate;
	@Column(name="plan_end_date")
	private String planEndDate;
	@Column(name="remaining_data_in_gb")
	private String remainingDataInGb;
	@Column(name="remaining_sms")
	private String remainingSms;
	@Column(name="remaining_talktime")
	private String remainingTalkTime;
	
	

}
