package com.example.demo.dto;
 
import java.time.LocalDateTime;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDTO {
    private int transactionId;
    private String transactionStatus;
    private String paymentMode;
    private LocalDateTime transactionTimestamp;
    private String planName;
    private String planType;
    private String dataInGb;
	private String sms;
	private String talkTime;
    private double planPrice;
}