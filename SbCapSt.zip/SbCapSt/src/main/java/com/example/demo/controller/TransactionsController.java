package com.example.demo.controller;
 
import java.util.List;
import java.util.NoSuchElementException;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.example.demo.dto.TransactionDTO;
import com.example.demo.model.Transactions;
import com.example.demo.model.datausage;
import com.example.demo.services.TransactionsService;
 
@RestController
@RequestMapping(value = "/transactions")
public class TransactionsController {
   
    @Autowired
    private TransactionsService transactionsServices;
   
//  @GetMapping(value = "/showTrasactions")
//  public List<Transactions> showTransactions(){
//      return transactionsServices.showTransactions();
//  }
//  
//  @GetMapping(value = "/searchTransactions/{id}")
//  public ResponseEntity<Transactions> get(@PathVariable int id){
//      try {
//          Transactions transactions = transactionsServices.getTransactionsById(id);
//          return new ResponseEntity<Transactions>(transactions,HttpStatus.OK);
//      }catch(NoSuchElementException e){
//          return new ResponseEntity<Transactions>(HttpStatus.NOT_FOUND);
//      }
//  }
//  
//  @PostMapping(value = "/addTransactions")
//  public void addTransactions(@RequestBody Transactions transactions) {
//      transactionsServices.addTransactions(transactions);
//  }
   
//  @GetMapping(value = "/searchUser/{userId}")
//  public ResponseEntity<List<Transactions>> getDataUsageByUserId(@PathVariable int userId){
//      try {
//          List<Transactions> transactionsList = transactionsServices.getTransactionsByUserId(userId);
//          return new ResponseEntity<List<Transactions>>(transactionsList,HttpStatus.OK);
//      } catch (NoSuchElementException e) {
//          return new ResponseEntity<List<Transactions>>(HttpStatus.NOT_FOUND);
//      }
//  }
   
    // Endpoint to get transaction history for a specific user
    @GetMapping("/transactionHistory/{userId}")
    public ResponseEntity<List<TransactionDTO>> getTransactionHistory(@PathVariable("userId") int userId) {
        try {
            // Fetch transaction history using the service layer
            List<TransactionDTO> transactionHistory = transactionsServices.getTransactionHistory(userId);
 
            // Check if there are transactions for the user
            if (transactionHistory.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT); // No transactions found
            }
 
            return new ResponseEntity<>(transactionHistory, HttpStatus.OK); // Return transactions
 
        } catch (Exception e) {
            // If there's an error, return a bad request status with error message
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
   
   
   
}