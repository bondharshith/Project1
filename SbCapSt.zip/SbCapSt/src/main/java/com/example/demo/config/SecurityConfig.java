package com.example.demo.config;
 
import com.example.demo.services.UsersService;
 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
 
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
 
    @Autowired
    private JwtAuthFilter authFilter;
 
    @Autowired
    private UsersService usersService;

        @Bean
        public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
            return http.csrf(csrf -> csrf.disable())
                    .cors(Customizer.withDefaults())  // Enable CORS globally
                    .authorizeHttpRequests(auth -> 
                        auth.requestMatchers("/accounts/addAccount", "/accounts/generateToken").permitAll()
                            .requestMatchers("/accounts/getAccountByMobileNumber/**").permitAll()
                            .requestMatchers("/accounts/getAccountByEmail/**").permitAll()
                            .requestMatchers("/accounts/**").permitAll()
                            .requestMatchers("/plans/**").permitAll()
                            .requestMatchers("/datausage/**").permitAll()
                            .requestMatchers("/billing/**").permitAll()
                            .requestMatchers("/billing/searchUser/**").permitAll()
                            .requestMatchers("/transactions/**").permitAll()
                            .requestMatchers("/userplan/**").permitAll()
                            .requestMatchers("/supportTickets/**").permitAll()
                            .requestMatchers("/chatbot/**").permitAll()
                    )
                    .sessionManagement(sess -> sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .authenticationProvider(authenticationProvider())
                    .addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class)
                    .build();
        }
 
        @Bean
        public PasswordEncoder passwordEncoder() {
            return new BCryptPasswordEncoder();
        }
 
        @Bean
        public AuthenticationProvider authenticationProvider() {
            DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
            authenticationProvider.setUserDetailsService(usersService);
            authenticationProvider.setPasswordEncoder(passwordEncoder());
            return authenticationProvider;
        }
 
        @Bean
        public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
            return config.getAuthenticationManager();
        }
    }