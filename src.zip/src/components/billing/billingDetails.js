import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import AuthService from "../../services/AuthService";
import UserMenu from "../Users/userMenu";
 
const BillingDetails = () => {
  const [billingData, setBillingData] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
 
  useEffect(() => {
    const token = AuthService.getCurrentUserToken();
    const accountNo = localStorage.getItem("UserId");
 
    if (!token) {
      console.error("No JWT token found. Redirecting to login.");
      navigate("/login");
      return;
    }
 
    if (!accountNo) {
      console.error("No account number found. Redirecting to login.");
      navigate("/login");
      return;
    }
 
    const fetchBillingDetails = async () => {
      try {
        const response = await axios.get(
          `http://localhost:1121/billing/getBillingDetails/${accountNo}`,
          {
            headers: {
              Authorization: `Bearer ${token}`, // Include JWT token in the Authorization header
            },
          }
        );
        setBillingData(response.data);
        setError(null);
      } catch (err) {
        setError("Error fetching billing details!");
        setBillingData(null);
        // console.error("Error fetching billing details:", err);
      }
    };
 
    fetchBillingDetails();
  }, [navigate]);
 
  // Billing data fields as an array to map over
  const billingFields = [
    { label: "Billing Cycle", value: billingData?.billingCycle },
    { label: "Charges", value: `₹${billingData?.charges}` },
    { label: "Tax Amount", value: `₹${billingData?.taxAmount}` },
    { label: "Total Amount", value: `₹${billingData?.totalAmount}` },
    { label: "Due Date", value: billingData?.dueDate },
  ];
 
  return (
    <div style={styles.container}>
      <UserMenu />
      {error && <p style={styles.error}>{error}</p>}
      {billingData ? (
        <div style={styles.billingInfo}>
          <h3>Billing Details for User {billingData.userId}</h3>
          <table style={styles.table}>
            <tbody>
              {billingFields.map((field, index) => (
                <tr key={index}>
                  <td style={styles.tableCell}><strong>{field.label}:</strong></td>
                  <td style={styles.tableCell}>{field.value || "Not available"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p>Loading billing details...</p>
      )}
    </div>
  );
};
 
// Styling for the component
const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingTop: "50px",
    backgroundColor: "#f5f5f5",
    minHeight: "100vh",
    textAlign: "center",
  },
  error: {
    color: "red",
    fontSize: "18px",
    marginBottom: "20px",
  },
  billingInfo: {
    backgroundColor: "#fff",
    padding: "20px",
    borderRadius: "8px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    marginTop: "20px",
    width: "80%",
    maxWidth: "800px",
    textAlign: "left",
    lineHeight: "1.6",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    marginTop: "20px",
  },
  tableCell: {
    padding: "10px",
    borderBottom: "1px solid #ddd",
    textAlign: "left",
  },
};
 
export default BillingDetails;
 