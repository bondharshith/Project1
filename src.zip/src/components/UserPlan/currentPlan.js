import React, { useEffect, useState } from "react";
import axios from "axios";
import UserMenu from "../Users/userMenu";

const CurrentPlan = () => {
  const [currentPlan, setCurrentPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const token = localStorage.getItem("userToken");
  const userId = localStorage.getItem("UserId");

  useEffect(() => {
    const fetchCurrentPlan = async () => {
      if (!userId || !token) {
        setError("User not logged in or missing token.");
        setLoading(false);
        return;
      }

      try {
        const response = await axios.get(
          `http://localhost:4000/userplan/searchUser/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        console.log("API Response:", response.data); // Debugging
        if (response.data && response.data.length > 0) {
          setCurrentPlan(response.data[0]); // Extract the first object
        } else {
          setError("No active plan found.");
        }
      } catch (error) {
        console.error("Error fetching current plan:", error);
        setError("Failed to fetch current plan details.");
      } finally {
        setLoading(false);
      }
    };

    fetchCurrentPlan();
  }, [userId, token]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;
  if (!currentPlan) return <div>No active plan found.</div>;

  return (
    <div style={styles.container}>
      <UserMenu />
      <h2>Current Plan Details</h2>
      <div style={styles.planCard}>
        <table style={styles.table}>
          <tbody>
            <tr>
              <td><b>Start Date:</b></td>
              <td>{currentPlan.planStartDate || "N/A"}</td>
            </tr>
            <tr>
              <td><b>End Date:</b></td>
              <td>{currentPlan.planEndDate || "N/A"}</td>
            </tr>
            <tr>
              <td><b>Data (GB):</b></td>
              <td>{currentPlan.remainingDataInGb ?? "N/A"}</td>
            </tr>
            <tr>
              <td><b>SMS:</b></td>
              <td>{currentPlan.remainingSms ?? "N/A"}</td>
            </tr>
            <tr>
              <td><b>Talk Time:</b></td>
              <td>{currentPlan.remainingTalkTime ?? "N/A"}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

const styles = {
  container: {
    textAlign: "center",
    padding: "20px",
  },
  planCard: {
    maxWidth: "600px",
    margin: "0 auto",
    padding: "20px",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
    borderRadius: "8px",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
  },
};

export default CurrentPlan;
