import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';

const UserPlan = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const userId = localStorage.getItem("UserId");
  const token = localStorage.getItem("userToken");

  // Get planId from location state
  const planId = location.state?.planId;

  useEffect(() => {
    if (!planId || !userId || !token) {
      setError("Missing required information");
      setLoading(false);
      return;
    }

    const fetchPlanDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:4000/plans/searchPlans/${planId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setPlan(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching plan details:", error);
        setError("Failed to fetch plan details");
        setLoading(false);
      }
    };

    fetchPlanDetails();
  }, [planId, userId, token]);

  const handleRecharge = async () => {
    const planStartDate = new Date().toISOString().split('T')[0];

    try {
      await axios.post(
        "http://localhost:4000/userplan/assignPlan",
        {
          userId: parseInt(userId),
          planId: parseInt(planId),
          planStartDate
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      alert("Plan recharged successfully!");
      navigate('/userMenu');
    } catch (error) {
      console.error("Error recharging plan:", error);
      alert("Failed to recharge plan. Please try again.");
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;
  if (!plan) return <div>No plan selected.</div>;

  return (
    <div style={styles.container}>
      <h2>Selected Plan Details</h2>
      <div style={styles.planCard}>
        <table style={styles.table}>
          <tbody>
            <tr><td><b>Plan Name:</b></td><td>{plan.planName}</td></tr>
            <tr><td><b>Plan Type:</b></td><td>{plan.planType}</td></tr>
            <tr><td><b>Data (GB):</b></td><td>{plan.dataInGb}</td></tr>
            <tr><td><b>SMS:</b></td><td>{plan.sms}</td></tr>
            <tr><td><b>Talktime:</b></td><td>{plan.talktime}</td></tr>
            <tr><td><b>Price (INR):</b></td><td>{plan.price}</td></tr>
            <tr><td><b>Validity (Days):</b></td><td>{plan.validity}</td></tr>
          </tbody>
        </table>
        <button onClick={handleRecharge} style={styles.button}>
          Recharge Now
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    textAlign: 'center',
    padding: '20px',
    maxWidth: '800px',
    margin: '0 auto'
  },
  planCard: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    padding: '20px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    margin: '20px auto'
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    marginBottom: '20px'
  },
  button: {
    padding: '12px 24px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '16px'
  }
};

export default UserPlan;