import React from "react";
import { Link, useNavigate } from "react-router-dom";

const UserMenu = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem("userToken");
        localStorage.removeItem("mobileNumber");
        navigate("/login");
    };

    return (
        <div style={{ textAlign: "center", marginTop: "50px" }}>
            <h2>Welcome to User Dashboard</h2>

            <nav>
                <ul style={horizontalMenuStyle}>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/userinfo" style={buttonStyle}>User Info</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/plans" style={buttonStyle}>Plans</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/currentplan" style={buttonStyle}>Current Plan</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/datausage" style={buttonStyle}>Data Usage</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/tickets" style={buttonStyle}>Support Tickets</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/chatbot" style={buttonStyle}>Telexa</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/billingdetails" style={buttonStyle}>BillingDetails</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <button onClick={handleLogout} style={buttonStyle}>Logout</button>
                    </li>
                </ul>
            </nav>
        </div>
    );
};

const horizontalMenuStyle = {
    listStyle: "none",
    padding: 0,
    display: "flex",
    justifyContent: "center",
    gap: "20px",
    flexWrap: "wrap"
};

const horizontalMenuItemStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
};

const buttonStyle = {
    padding: "10px 20px",
    backgroundColor: "blue",
    color: "white",
    border: "none",
    cursor: "pointer",
    fontSize: "16px",
    borderRadius: "5px",
    textDecoration: "none",
    fontWeight: "bold",
    textAlign: "center",
};

export default UserMenu;