import React, { useState, useEffect } from 'react';
import axios from 'axios';
import UserMenu from '../Users/userMenu';
import { useNavigate } from 'react-router-dom';

const Plans = () => {
  const [data, setData] = useState([]);
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:4000/plans/showPlans", {
          headers: { Authorization: `Bearer ${token}` }
        });
        setData(response.data);
      } catch (error) {
        console.error("Error fetching plans:", error);
        alert("Unauthorized Access. Please log in again.");
      }
    };
    fetchData();
  }, [token]);

  const handlePlanSelection = (planId) => {
    navigate('/userplan', { state: { planId: planId }});
  };

  return (
    <div>
      <UserMenu />
      <h2 style={{ textAlign: 'center' }}>Available Plans</h2>
      <table 
        border="1" 
        align="center" 
        style={{ 
          borderCollapse: 'collapse', 
          margin: '20px auto',
          width: '80%',
          cursor: 'pointer'
        }}
      >
        <thead>
          <tr>
            <th>Plan ID</th>
            <th>Plan Name</th>
            <th>Plan Type</th>
            <th>Data (GB)</th>
            <th>SMS</th>
            <th>Talktime</th>
            <th>Price (INR)</th>
            <th>Validity (Days)</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr 
              key={item.planId}
              onClick={() => handlePlanSelection(item.planId)}
              style={{ backgroundColor: '#fff', transition: '0.3s' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f5f5f5'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = ''}
            >
              <td>{item.planId}</td>
              <td>{item.planName}</td>
              <td>{item.planType}</td>
              <td>{item.dataingb}</td>
              <td>{item.sms}</td>
              <td>{item.talktime}</td>
              <td>{item.price}</td>
              <td>{item.validity}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Plans;