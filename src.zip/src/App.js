import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './components/Users/login';
import UserMenu from './components/Users/userMenu';
import UserInfo from './components/Users/userInfo';
import ProtectedRoute from './components/Users/ProtectedRoute';
import Register from './components/Users/register';
import LandingPage from './components/Users/landingpage';
//import Tickets
import Chatbot from './components/chatbot/chatbot';
import Plans from './components/plans/plans';
import Datausage from './components/datausage';
import UserPlan from './components/UserPlan/userPlan';
import CurrentPlan from './components/UserPlan/currentPlan';
import BillingDetails from './components/billing/billingDetails';

function App() {
  return (
    <Router>
      <Routes>
         <Route path="/" element={<LandingPage/>}/>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register/>}/>
        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="/userMenu" element={<UserMenu />} />
          <Route path="/userInfo" element={<UserInfo />} />
          <Route path="/datausage" element={<Datausage />} />
       {/* <Route path="/tickets" element={<Tickets />} />  */}
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/plans" element={<Plans />} />
          <Route path="/userPlan" element={<UserPlan/>} />
          <Route path="/currentPlan" element={<CurrentPlan/>}/>
          <Route path="/billing" element={<BillingDetails/>}/>
          


        </Route>

        {/* Redirect all other paths to /login */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;